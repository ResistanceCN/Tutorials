# Example

This is a minimal example configuration.
